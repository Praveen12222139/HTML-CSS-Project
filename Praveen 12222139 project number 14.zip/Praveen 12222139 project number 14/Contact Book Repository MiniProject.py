while True:
    x=input('Add(a)' 'Search(s)' 'Quit(q)')
    if x=='a':
        with open('Contact.txt','a') as f:
            name=input('Name: ')
            phone=input('Phone: ')
            f.writelines((name,':',phone,'\n'))
    elif x=='s':
        with open("Contact.txt","r") as f:
            search=input("Search: ")
            for i in f:
                if search in i:
                    print(i)
    else:
        break