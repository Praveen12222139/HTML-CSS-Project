file1=open("file.txt","r")
TConsonant=0
TVowel=0
while True:
    Vowel=0
    line=file1.readline()
    line=line.lower()
    if line=="":
        break
    if line.find("a")!=-1:
        Vowel+=line.count('a')
    if line.find('e')!=-1:
        Vowel+=line.count('e')
    if line.find('i')!=-1:
        Vowel+=line.count('i')
    if line.find('o')!=-1:
        Vowel+=line.count('o')
    if line.find('u')!=-1:
        Vowel+=line.count('u')
    TConsonant+=len(line)-1-Vowel
    TVowel+=Vowel

print("TConsonant",TConsonant,"TVowel",TVowel)
file1.close()

